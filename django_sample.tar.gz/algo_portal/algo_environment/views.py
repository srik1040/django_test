from django.shortcuts import render

import collections
import csv
import datetime
import logging
import os
import time

LOG = logging.getLogger(__name__)

ALL_ENVS = ('DaVinci', 'SOR', 'ECN')

DATA_DIR = '/export/algodev/data0/algodev/algo_environment'

StatusInfo = collections.namedtuple('StatusInfo',
                                    ['env_name', 'status_time', 'down_count', 'header', 'data'])

def get_status(env):
    date = datetime.date.today()
    timedelta = datetime.timedelta(days=1)

    for i in xrange(0, 10):
        file = os.path.join(DATA_DIR,
                            '%sStatus.%s.csv' % (env.lower(), date.strftime('%Y%m%d')))

        if os.path.exists(file):
            LOG.debug('Reading status information in file: ' + file)
            status_time = time.ctime(os.path.getmtime(file))
            down_count = 0
            data = []
            with open(file) as fh:
                reader = csv.reader(fh)
                for row in reader:
                    data.append(row)
                    if row[-1] == 'DOWN':
                        down_count += 1
            if len(data) > 1:
                return StatusInfo(env, status_time, down_count, data[0], data[1:])
        else:
            LOG.debug('Status information file not found: ' + file)

        date -= timedelta

    return StatusInfo(env, '?', '?', [], [])


# Create your views here.

def index(request):
    env_status = [get_status(env) for env in ALL_ENVS]

    LOG.debug('Status information: ' + str(env_status))

    return render(request,
                  'algo_environment/index.html',
                  {'env_status': env_status})
