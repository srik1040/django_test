from django.conf.urls import patterns, include, url
from django.contrib import admin
from algo_reports import views

urlpatterns = patterns('',
    # Examples:
    # url(r'^$', 'algo_portal.views.home', name='home'),
    # url(r'^blog/', include('blog.urls')),

    url(r'^reports/', include('algo_reports.urls', namespace='reports')),
    url(r'^environment/', include('algo_environment.urls', namespace='environment')),
    url(r'^admin/', include(admin.site.urls)),
)

handler404 = views.custom_404
