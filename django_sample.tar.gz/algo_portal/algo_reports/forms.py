from datetime import date, datetime, timedelta
from django import forms
from django.forms.widgets import DateInput

import models
import os
import settings
import util

FORMAT_DATE  = '%Y-%m-%d'
FORMAT_MONTH = '%Y-%m'

class BidAskInputForm(forms.Form):

    date = forms.CharField(widget=forms.TextInput(attrs={'id': 'id_bask_date'}))

    def __init__(self, *args, **kw):
        super(BidAskInputForm, self).__init__(*args, **kw)
        for field, value in self._get_initial_values().items():
            self.fields[field].initial = value

    def clean(self):
        cleaned_data = super(BidAskInputForm, self).clean()

        if self._errors:
            return cleaned_data

        try:
            dt = cleaned_data['date']
            cleaned_data['date'] = datetime.strptime(dt, FORMAT_DATE).date()
        except ValueError:
            self.add_error('date', 'Invalid value: %s' % (dt,))
            raise

        if len(self.results()) == 0:
            raise forms.ValidationError(self.desc() + ': None found!!')

        return cleaned_data

    def desc(self):
        return 'Bid/Ask/Trade Percentile [Date: %s]' % (self.cleaned_data['date'],)

    def results(self):
        return self._get_results(self.cleaned_data['date'])

    def _get_results(self, dt):
        filename = format(dt, 'bidAskTradePtiles.%Y%m%d.csv')
        path = util.find_file(filename)
        return [] if path is None else [os.path.basename(path)]

    def _get_initial_values(self):
        initials = {'date': format(datetime.today(), FORMAT_DATE)}

        dt = datetime.today()
        delta = timedelta(days=1)

        for i in xrange(0, 10):
            if self._get_results(dt):
                initials['date'] = format(dt, FORMAT_DATE)
                break
            dt -= delta

        return initials


class CorrelationInputForm(forms.Form):
    date = forms.CharField(widget=forms.TextInput(attrs={'id': 'id_corr_date'}))

    def __init__(self, *args, **kw):
        super(CorrelationInputForm, self).__init__(*args, **kw)
        for field, value in self._get_initial_values().items():
            self.fields[field].initial = value

    def clean(self):
        cleaned_data = super(CorrelationInputForm, self).clean()

        if self._errors:
            return cleaned_data

        try:
            dt = cleaned_data['date']
            cleaned_data['date'] = datetime.strptime(dt, FORMAT_DATE).date()
        except ValueError:
            self.add_error('date', 'Invalid value: %s' % (dt,))
            raise

        if len(self.results()) == 0:
            raise forms.ValidationError(self.desc() + ': None found!!')

        return cleaned_data

    def desc(self):
        return 'Correlation Results [Date: %s]' % (self.cleaned_data['date'],)

    def results(self):
        return self._get_results(self.cleaned_data['date'])

    def _get_results(self, dt):
        filename = format(dt, 'CorrelationResults.%Y%m%d.csv')
        path = util.find_file(filename)
        return [] if path is None else [os.path.basename(path)]

    def _get_initial_values(self):
        initials = {'date': format(datetime.today(), FORMAT_DATE)}

        dt = datetime.today()
        delta = timedelta(days=1)

        for i in xrange(0, 10):
            if self._get_results(dt):
                initials['date'] = format(dt, FORMAT_DATE)
                break
            dt -= delta

        return initials


class MoneyballInputForm(forms.Form):
    month = forms.CharField(widget=forms.TextInput())
    cleaned_data = {'month': datetime.strptime(format(datetime.today(), "%Y-%m"), FORMAT_MONTH).date()}

    def __init__(self, *args, **kw):
        super(MoneyballInputForm, self).__init__(*args, **kw)
        for field, value in self._get_initial_values().items():
            self.fields[field].initial = value

    def clean(self):
        cleaned_data = super(MoneyballInputForm, self).clean()

        if self._errors:
            return cleaned_data

        try:
            mt = cleaned_data['month']
            cleaned_data['month'] = datetime.strptime(mt, FORMAT_MONTH).date()
        except ValueError:
            self.add_error('month', 'Invalid value: %s' % (dt,))
            raise

        if len(self.results()) == 0:
            raise forms.ValidationError(self.desc() + ': None found!!')

        return cleaned_data

    def desc(self, dtstring=''):
        if dtstring:
            month = datetime.strptime(dtstring, FORMAT_MONTH).date().strftime('%b-%Y')
        else:
            month = self.cleaned_data['month'].strftime('%b-%Y')
        return 'Moneyball Reports [Month: %s]' % (month,)

    def results(self, datestring=''):
        if datestring:
            return self._get_results(datetime.strptime(datestring, FORMAT_MONTH).date())
        else:
            return self._get_results(self.cleaned_data['month'])

    def _get_results(self, month):
        search_dir = os.path.join(settings.DATA_DIR,
                                  'moneyball',
                                  format(month, '%Y%m'))
        if os.path.exists(search_dir) and os.path.isdir(search_dir):
            (_, _, files) = os.walk(search_dir).next()
            files.sort()
            return files
        else:
            return []

    def _get_initial_values(self):
        initials = {'month': format(datetime.today(), FORMAT_MONTH)}

        dt = datetime.today()
        delta = timedelta(days=1)

        for i in xrange(0, 10):
            if self._get_results(dt):
                initials['month'] = format(dt, FORMAT_MONTH)
                break
            dt = dt.replace(day=1) - delta

        return initials


class ClientInputForm(forms.Form):
    TIME_RANGES = tuple((t, t) for t in ('Date', 'YTD', 'MTD', 'Q1', 'Q2', 'Q3', 'Q4'))

    time_range = forms.ChoiceField(widget=forms.RadioSelect,
                                   choices=TIME_RANGES,
                                   initial='Date')
    date = forms.CharField(widget=forms.TextInput(attrs={'id': 'id_client_date',
                                                         'value': date.today().strftime(FORMAT_DATE)}))
    client = forms.ChoiceField(choices=models.CLIENTS)
    desk = forms.ChoiceField(choices=models.TRADING_DESKS)

    def clean(self):
        cleaned_data = super(ClientInputForm, self).clean()

        if self._errors:
            return cleaned_data

        if cleaned_data.get('time_range', None) == 'Date':
            try:
                dt = cleaned_data['date']
                cleaned_data['date'] = datetime.strptime(dt, FORMAT_DATE).date()
            except ValueError:
                self.add_error('time_range', 'Invalid value: %s' % (dt,))
                raise

        if len(self.results()) == 0:
            raise forms.ValidationError(self.desc() + ': None found!!')

        return cleaned_data

    def desc(self):
        time_range = self.cleaned_data['time_range']
        if time_range == 'Date':
            time_range += ' (%s)' % (self.cleaned_data['date'],)
        client = self.cleaned_data['client']
        desk = self.cleaned_data['desk']
        return 'Client Reports [Client(s): %s, Desk: %s, TimeRange: %s]' % (client, desk, time_range)

    def results(self):
        # XXX To be implemented
        return []


class LiquidityInputForm(forms.Form):
    date = forms.CharField(widget=forms.TextInput(attrs={'id': 'id_lqdty_date'}))

    def __init__(self, *args, **kw):
        super(LiquidityInputForm, self).__init__(*args, **kw)
        for field, value in self._get_initial_values().items():
            self.fields[field].initial = value

    def clean(self):
        cleaned_data = super(LiquidityInputForm, self).clean()

        if self._errors:
            return cleaned_data

        try:
            dt = cleaned_data['date']
            cleaned_data['date'] = datetime.strptime(dt, FORMAT_DATE).date()
        except ValueError:
            self.add_error('date', 'Invalid value: %s' % (dt,))
            raise

        if len(self.results()) == 0:
            raise forms.ValidationError(self.desc() + ': None found!!')

        return cleaned_data

    def desc(self):
        return 'Liquidity Reports [Date: %s]' % (self.cleaned_data['date'],)

    def results(self):
        date = self.cleaned_data['date']
        return self._get_results(self.cleaned_data['date'])

    def _get_results(self, dt):
        search_dir = os.path.join(settings.DATA_DIR, 'liquidity', format(dt, '%Y%m%d'))
        if os.path.exists(search_dir) and os.path.isdir(search_dir):
            (_, _, files) = os.walk(search_dir).next()
            files.sort()
            return files
        else:
            return []

    def _get_initial_values(self):
        initials = {'date': format(datetime.today(), FORMAT_DATE)}

        dt = datetime.today()
        delta = timedelta(days=1)

        for i in xrange(0, 10):
            if self._get_results(dt):
                initials['date'] = format(dt, FORMAT_DATE)
                break
            dt -= delta

        return initials

