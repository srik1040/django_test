from django.db import models

# Create your models here.

CLIENTS = (('All', 'All'),
           ('PineRiver', 'PineRiver'),
           ('Citadel', 'Citadel'),
           ('BlackRock', 'BlackRock'))

TRADING_DESKS = (('WATS', 'WATS'),
                 ('CASH', 'CASH'),
                 ('PT', 'PT'),
                 ('WEMM', 'WEMM'))

