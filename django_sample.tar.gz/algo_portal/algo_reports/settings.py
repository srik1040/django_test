"""
Constants/settings for algo_reports.
"""

DATA_DIR = '/export/algodev/data0/algodev/algo_reports'

