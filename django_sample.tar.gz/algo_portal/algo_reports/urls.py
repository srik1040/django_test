from django.conf.urls import patterns, url
from django.views.generic import RedirectView

from algo_reports import views

urlpatterns = patterns('',
    url(r'^$', views.index, name='index'),
    url(r'^results/$', views.results, name='results'),
    url(r'^moneyball/(?P<datestring>[-\w]+)/$', views.moneyball_results, name='moneyball_results'),
    url(r'^moneyball/view/(?P<file>\S+)$', views.view, name='moneyball_view'),
    url(r'^bidask/view/(?P<file>\S+)$', views.view, name='bidask_view'),
    url(r'^view/(?P<file>\S+)$', views.view, name='view'),  # Old one
    url(r'^download/(?P<file>\S+)$', views.download, name='download'),
)
