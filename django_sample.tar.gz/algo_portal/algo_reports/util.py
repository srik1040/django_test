import collections
import csv
import os
import settings

def find_file(file, directory=settings.DATA_DIR):
    """
    Searches for the specified in the given directory and returns
    the path to the first one found.
    """
    for root, dirnames, filenames in os.walk(directory):
        if file in filenames:
            return os.path.join(root, file)
        for dir in dirnames:
            path = find_file(file, os.path.join(root, dir))
            if path is not None:
                return path

    return None


Table = collections.namedtuple('Table', ['caption', 'header', 'data', 'footer'])

def parse_file(file):
    tables = []
    caption, rows, footer, prev_row_empty = [], [], [], False

    def clean(value):
        value = value.strip()
        try:
            return format(int(value), ',')
        except ValueError:
            try:
                return format(float(value), ',')
            except ValueError:
                pass

        return value

    with open(file) as csvfile:
        reader = csv.reader(csvfile)
        for row in reader:
            if (len(row) == 0) or (not any(row)):
                if len(footer) > 0:
                    tables.append(Table(caption, rows[0], rows[1:], footer))
                    caption, rows, footer, prev_row_empty = [], [], [], False
            elif len(row) == 1:
                if prev_row_empty and len(rows) > 0:
                    tables.append(Table(caption, rows[0], rows[1:], footer))
                    caption, rows, footer, prev_row_empty = [], [], [], False

                if len(rows) == 0:
                    caption.append(row[0])
                else:
                    footer.append(row[0])
            elif len(row) > 0:
                if rows and len(rows[0]) != len(row):
                    tables.append(Table(caption, rows[0], rows[1:], footer))
                    caption, rows, footer, prev_row_empty = [], [], [], False

                rows.append([clean(v) for v in row])

            prev_row_empty = (len(row) == 0) or (not any(row))

    if len(rows) > 0:
        tables.append(Table(caption, rows[0], rows[1:], footer))

    return tables

