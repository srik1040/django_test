from django.core.urlresolvers import reverse, resolve
from django.http import Http404, HttpResponse, HttpResponseRedirect
from django.shortcuts import render, render_to_response
from django.views.defaults import page_not_found

from forms import BidAskInputForm, ClientInputForm, CorrelationInputForm, \
                  LiquidityInputForm, MoneyballInputForm

import csv
import util

# Create your views here.

#ALL_TABS = ('BidAsk', 'Correlation', 'Moneyball', 'Liquidity')
ALL_TABS = ('BidAsk', 'Moneyball')

def index(request):
    moneyball_form = MoneyballInputForm()
    clients_form = ClientInputForm()
    correlation_form = CorrelationInputForm()
    bidask_form = BidAskInputForm()
    liquidity_form = LiquidityInputForm()
    active_tab = ALL_TABS[0]
    if request.method == 'GET':
        active_tab = request.GET.get('tab', ALL_TABS[0])

    if request.method == 'POST':
        # Bind data from request.POST into a PostForm
        if 'moneyball' in request.POST:
            form = moneyball_form = MoneyballInputForm(request.POST)
            active_tab = 'Moneyball'
        elif 'clients' in request.POST:
            form = clients_form = ClientInputForm(request.POST)
            active_tab = 'Clients'
        elif 'correlation' in request.POST:
            form = correlation_form = CorrelationInputForm(request.POST)
            active_tab = 'Correlation'
        elif 'bidask' in request.POST:
            form = bidask_form = BidAskInputForm(request.POST)
            active_tab = 'BidAsk'
        elif 'liquidity' in request.POST:
            form = liquidity_form = LiquidityInputForm(request.POST)
            active_tab = 'Liquidity'

        # If data is valid, proceeds to create a new post and redirect the user
        if form.is_valid():
            request.session['active_tab'] = active_tab
            results = form.results()
            # If there's only one result (file), display the file contents
            # directly.
            if len(results) == 1:
                return HttpResponseRedirect(reverse('reports:view', args=results ))
            else:
                request.session['_input_desc'] = form.desc()
                request.session['_results'] = results
                return HttpResponseRedirect(reverse('reports:results'))

    return render(request,
                  'algo_reports/index.html',
                  {
                     'bidask_form': bidask_form,
                     'clients_form': clients_form,
                     'correlation_form': correlation_form,
                     'liquidity_form': liquidity_form,
                     'moneyball_form': moneyball_form,
                     'all_tabs': ALL_TABS,
                     'active_tab': active_tab,
                  }) 

def results(request):
    input_desc = request.session.get('_input_desc', '')
    results = request.session.get('_results', [])
    active_tab = request.session.get('active_tab', ALL_TABS[0])
    return render(request,
                  'algo_reports/results.html',
                  { 'input_desc': input_desc, 'results': results,
                    'all_tabs': ALL_TABS,
                    'active_tab': active_tab,
                  })


def view(request, file):
    active_tab = request.session.get('active_tab', '')
    tab_name = request.path.split("/")[2].title()
    if tab_name in ALL_TABS:
        active_tab = tab_name    
    path = util.find_file(file)
    if not path:
        raise Http404('%s: File not found' % (file,))

    tables = util.parse_file(path)
    if not tables:
        raise Http404("File found at %s. But file is empty, unable to process." % (file))

    return render(request,
                  'algo_reports/view.html',
                  { 'file': file,
                    'tables': tables,
                    'caption': tables[0].caption,
                    'header': tables[0].header,
                    'data': tables[0].data,
                    'footer': tables[0].footer,
                    'active_tab': active_tab,
                    'all_tabs': ALL_TABS,
                  })

def download(request, file):
    path = util.find_file(file)
    if not path:
        raise Http404('%s: File not found' % (file,))

    # XXX Would it be a csv file always?
    response = HttpResponse(content_type='text/csv')
    response['Content-Disposition'] = 'attachment; filename="%s"' % (file,)

    writer = csv.writer(response)
    with open(path) as csvfile:
        reader = csv.reader(csvfile)
        for row in reader:
            writer.writerow(row)

    return response

def moneyball_results(request, datestring=''):
    active_tab = 'Moneyball'
    form = moneyball_form = MoneyballInputForm(request.POST, initial={'month': datestring})
    results = form.results(datestring)
    input_desc = form.desc(datestring)
    # return HttpResponseRedirect(reverse('reports:index'))
    return render(request,
                 'algo_reports/results.html',
                 { 'input_desc': input_desc,
                 'results': results,
                 'all_tabs': ALL_TABS,
                 'active_tab': active_tab,
                  })
    return HttpResponseRedirect(reverse('reports:index'))

def custom_404(request):
    return page_not_found(request, template_name='404.html')
