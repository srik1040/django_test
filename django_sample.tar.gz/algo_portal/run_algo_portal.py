#!/usr/bin/env python

#
# $Header$
#

"""
Launcher script for the Algo Web Portal.
"""

import argparse
import django
import os
import socket
import sys

from algo_portal import settings
from django.core import management
from tempfile import NamedTemporaryFile

def main(arguments):

    parser = argparse.ArgumentParser(description=__doc__,
                                     formatter_class=argparse.ArgumentDefaultsHelpFormatter)
    parser.add_argument("port", nargs='?', help="Server Port", type=int, default=9090)
    args = parser.parse_args(arguments)

    script = os.path.splitext(os.path.basename(__file__))[0]

    # Use a temporary file for the database.
    # This gets deleted once the script exits.
    f = NamedTemporaryFile(prefix=script + '_',
                           dir=settings.RUN_DIRECTORY,
                           suffix='_db.sqlite',
                           delete=True)
    settings.DATABASES['default']['NAME'] = f.name

    host_ip = socket.gethostbyname(socket.getfqdn())
    ip_port = host_ip + ':' + str(args.port)

    os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'algo_portal.settings')

    django.setup()

    management.call_command('migrate')
    management.call_command('runserver', ip_port)


if __name__ == '__main__':
    sys.exit(main(sys.argv[1:]))
